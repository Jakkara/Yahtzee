/**
 * @author Jali
 *
 */
import java.security.SecureRandom;
public class Dice{
	protected int value = -50; //n�hd��n helposti jos noppaa ei ole viel� heitetty
	SecureRandom rnjeesus;
	
	//arvotaan luku v�lilt� 1-6
	public void throwDice(){
		rnjeesus = new SecureRandom();
		value = rnjeesus.nextInt(6) + 1;
	}
	//palauta luku
	public int getValue(){
		return value;
	}
	public void resetDice(){
		value = 0;
	}
}