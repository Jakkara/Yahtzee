import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.imageio.ImageIO;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JComponent;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JMenuBar;
import javax.swing.UIManager;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JMenuItem;

public class guidemo {

	private static JFrame frame;
	private JTable table;
	private JToggleButton button_0;
	private JToggleButton button_1;
	private JToggleButton button_2;
	private JToggleButton button_3;
	private JToggleButton button_4;
	private boolean[] valitut;
	private File kuva;
	private BufferedImage tausta;
	private static int player;
	private int throwCount;
	private boolean throwable;


	
	//Pistetaulut JTable-taulukkoa varten.
	
	String[] columnNames = {
			"K�det",	
			"Pelaaja 1",
			"Pelaaja 2"
			};

	Object[][] data = { //tallennetaan pelaajien pisteet matriisiin, joka sis�lt�� eri pelaajien pisteet eri sarakkeissa
			{"Ykk�set", 	null, null},
			{"Kakkoset", 	null, null},
			{"Kolmoset", 	null, null},
			{"Neloset", 	null, null},
			{"Vitoset", 	null, null},
			{"Kutoset", 	null, null},
			{"Bonus:", 		null, null},
			{"Pari", 		null, null},
			{"Kaksi paria", null, null},
			{"Kolme samaa", null, null},
			{"Nelj� samaa", null, null},
			{"Suora 1-5", 	null, null},
			{"Suora 2-6", 	null, null},
			{"T�ysk�si", 	null, null},
			{"Sattuma", 	null, null},
			{"Yatzy",		null, null},
			{"Yhteens�", 	null, null}
	};
	private JMenuBar menuBar;
	private JMenuItem mntmUusiPeli;
	private JMenuItem mntmAvaa;
	private JMenuItem menuItem;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					guidemo window = new guidemo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public guidemo() {
		initialize();
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Hand hand = new Hand();
		throwCount = 0;
		player = 1;
		throwable = true;
		
		//Valittu boolean[] -taulukko haluttujen noppien uudelleenheittoa varten
		valitut = new boolean[5];
		
		
		//Luodaan ikkuna
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 582);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		kuva = new File("src/background.jpg");
		
		//Lis�t��n taustakuva
		try {
			tausta = ImageIO.read(kuva);
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
		
		
		/*
		 *  VALIKKO
		 */
		menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		mntmUusiPeli = new JMenuItem("Uusi peli");
		mntmUusiPeli.addMouseListener(new MouseAdapter() {
			
			Object[] options = {"Peruuta",
                    "Ei",
                    "Kyll�"};
			@Override
			public void mouseClicked(MouseEvent e) {
			    JOptionPane.showOptionDialog(frame,
			    	    		"Haluatko tallentaa nykyisen pelin?",
			    	    	    "Uusi peli",
			    	    	    JOptionPane.YES_NO_CANCEL_OPTION,
			    	    	    JOptionPane.QUESTION_MESSAGE,
			    	    	    null,
			    	    	    options,
			    	    	    options[1]);
			    
			}
		});
		mntmUusiPeli.setFont(new Font("DIN", Font.PLAIN, 14));
		menuBar.add(mntmUusiPeli);
		
		mntmAvaa = new JMenuItem("Avaa");
		mntmAvaa.setFont(new Font("DIN", Font.PLAIN, 14));
		menuBar.add(mntmAvaa);
		
		menuItem = new JMenuItem("Tallenna");
		menuItem.setFont(new Font("DIN", Font.PLAIN, 14));
		menuBar.add(menuItem);
		frame.setContentPane(new ImagePanel(tausta));
		
		
		
		//Nopanheittopainike
		
		JButton btnNappula = new JButton("Heit� noppaa");
		btnNappula.setFont(new Font("DIN", Font.PLAIN, 13));
		btnNappula.setBounds(136, 388, 178, 29);
		btnNappula.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (throwable) {
				hand.throwHand(valitut);
				int[] nopat = hand.getHand();
				button_0.setText("" + nopat[0]);
				button_1.setText("" + nopat[1]);
				button_2.setText("" + nopat[2]);
				button_3.setText("" + nopat[3]);
				button_4.setText("" + nopat[4]);
				
				throwCount++;
				if (throwCount == 3) {
					throwable = false;
					
				}
				
				}	
			}
		});
		
		frame.getContentPane().setLayout(null);
		
		//Otsikko
		JLabel lblYahzee = new JLabel("Yatzy");
		lblYahzee.setBounds(17, 6, 415, 53);
		lblYahzee.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblYahzee.setHorizontalAlignment(SwingConstants.CENTER);
		lblYahzee.setBackground(Color.WHITE);
		lblYahzee.setFont(new Font("DIN", Font.PLAIN, 42));
		frame.getContentPane().add(lblYahzee);
		
		
		btnNappula.setBackground(UIManager.getColor("ComboBox.disabledForeground"));
		frame.getContentPane().add(btnNappula);
		
		
		//Kumpi pelaaja vuorossa:
		JLabel lblKtesi = new JLabel("Vuorossa pelaaja " + player);
		lblKtesi.setHorizontalAlignment(SwingConstants.CENTER);
		lblKtesi.setFont(new Font("DIN", Font.PLAIN, 13));
		lblKtesi.setBounds(125, 416, 200, 29);
		frame.getContentPane().add(lblKtesi);
		
		
		
		//Luodaan taulukko ScrollPanen sis��n:
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 72, 383, 292);
		frame.getContentPane().add(scrollPane);
		
		//Soluja ei saa pysty� muokkaamaan
		table = new JTable(data, columnNames) {
		        private static final long serialVersionUID = 1L;
		        public boolean isCellEditable(int row, int column) {                
		                return false;               
		        };
		};
		scrollPane.setViewportView(table);
		table.setToolTipText("Valitse haluamasi rivi");
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setRowSelectionAllowed(false);
		table.setFont(new Font("DIN", Font.PLAIN, 12));
		table.setCellSelectionEnabled(true);
		
		
		table.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
				  JTable target = (JTable)e.getSource();
			      int row = target.getSelectedRow();
			      int column = 0;
			      
			      // Mik�li rivi ei ole tyhj�, tulee varoitus ja pelaaja saa sijoittaa pisteens� uudelleen.
			      if (data[row][column+player] == null) {
				    if (e.getClickCount() == 2) {
				     
				      
				      // Tsekataan pisteet valitun rivin perusteella.
				      
				      //Ykk�set
				      if (row == 0) {
				    	  data[row][column+player] = hand.checkOne();
				      }
				      //Kakkoset
				      if (row == 1) {
				    	  data[row][column+player] = hand.checkTwo();
				      }
				      //Kolmoset
				      if (row == 2) {
				    	  data[row][column+player] = hand.checkThree();
				      }
				      //Neloset
				      if (row == 3) {
				    	  data[row][column+player] = hand.checkFour();
				      }
				      //Vitoset
				      if (row == 4) {
				    	  data[row][column+player] = hand.checkFive();
				      }
				      //Kutoset
				      if (row == 5) {
				    	  data[row][column+player] = hand.checkSix();
				      }
				      //Pari
				      if (row == 7) {
				    	  data[row][column+player] = hand.checkPair();
				      }
				      //Kaksi paria
				      if (row == 8) {
				    	  data[row][column+player] = hand.checkTwoPairs();
				      }
				      //Kolme samaa
				      if (row == 9) {
				    	  data[row][column+player] = hand.checkThreeofaKind();
				      }
				      //Nelj� samaa
				      if (row == 10) {
				    	  data[row][column+player] = hand.checkFourofaKind();
				      }
				      //Suora 1-5
				      if (row == 11) {
				    	  data[row][column+player] = hand.checkSmallStraight();
				      }
				      //Suora 2-6
				      if (row == 12) {
				    	  data[row][column+player] = hand.checkLargeStraight();
				      }
				      //M�kki
				      if (row == 13) {
				    	  data[row][column+player] = hand.checkFullHouse();
				      }
				      //Sattuma
				      if (row == 14) {
				    	  data[row][column+player] = hand.checkChance();
				      }
				      //Yatzy
				      if (row == 15) {
				    	  data[row][column+player] = hand.checkYahtzee();
				      }
				      
				      
			    	  
			    	  button_0.setSelected(false);
			    	  button_1.setSelected(false);
			    	  button_2.setSelected(false);
			    	  button_3.setSelected(false);
			    	  button_4.setSelected(false);
			    	  
			    	  for (int i = 0; i< 5 ; i++) {
			    		  valitut[i] = false;
			    	  }
			    	  
			    	  int bonuslaskuri = 0;
			    	  
			    	  for (int i=0;i<6;i++) {
			    		  if (data[i][player] instanceof Integer){
			    			  bonuslaskuri=bonuslaskuri + (int)data[i][player];
			    		  }
			    	  }
			    	  
			    	  if (bonuslaskuri >= 63) {
			    		  data[6][player] = 50;
			    	  }
			    	  
			    	  
			    	  //Nollataan seuraavaa heitt�j�� varten muuttujat:
			    	  hand.resetHand();
			    	  target.updateUI();
				      playerSwitch(data);
				      lblKtesi.setText("Vuorossa pelaaja " + player);
			    	  throwable = true;
			    	  throwCount = 0;
				    } 
			    } else {
			    	JOptionPane.showMessageDialog(frame,
			    	"Sinulla on jo pisteit� t�ss� k�dess�, valitse uudelleen!",
			    	"Senkin petkuttaja!",
			    	JOptionPane.PLAIN_MESSAGE);
			    }
			  }
			});
		
		
		
		

		/* Yatzynopat buttoneina, jokaiseen on lis�tty eventlistener 
		 * joka kertoo halutaanko noppa heitt�� vai ei
		 */
		
		//Noppa 1
		
		button_0 = new JToggleButton("");
		button_0.setFont(new Font("DIN", Font.PLAIN, 16));
		button_0.setBounds(33, 466, 50, 50);
		button_0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            JToggleButton tBtn = (JToggleButton)e.getSource();
	            if (tBtn.isSelected()) {
	            	valitut[0] = true;
	            } 
	            else if(tBtn.isSelected() != true) valitut[0] = false;
	            
			}
		});
		frame.getContentPane().add(button_0);
		
		//Noppa 2
		
		button_1 = new JToggleButton("");	
		button_1.setFont(new Font("DIN", Font.PLAIN, 16));
		button_1.setBounds(116, 466, 50,50);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            JToggleButton tBtn = (JToggleButton)e.getSource();
	            if (tBtn.isSelected()) {
	            	valitut[1] = true;
	            } 
	            else if(tBtn.isSelected() != true) valitut[1] = false;
			}
		});
		frame.getContentPane().add(button_1);
		
		//Noppa 3
		
		button_2 = new JToggleButton("");
		button_2.setFont(new Font("DIN", Font.PLAIN, 16));
		button_2.setBounds(199, 466, 50,50);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            JToggleButton tBtn = (JToggleButton)e.getSource();
	            if (tBtn.isSelected()) {
	            	valitut[2] = true;
	            } else valitut[2] = false;
			}
		});
		frame.getContentPane().add(button_2);
		
		//Noppa 4
		
		button_3 = new JToggleButton("");
		button_3.setFont(new Font("DIN", Font.PLAIN, 16));
		button_3.setBounds(282, 466, 50,50);
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            JToggleButton tBtn = (JToggleButton)e.getSource();
	            if (tBtn.isSelected()) {
	            	valitut[3] = true;
	            } else valitut[3] = false;
			}
		});
		frame.getContentPane().add(button_3);
		
		//Noppa 5
		
		button_4 = new JToggleButton("");
		button_4.setFont(new Font("DIN", Font.PLAIN, 16));
		button_4.setBounds(365, 466, 50,50);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            JToggleButton tBtn = (JToggleButton)e.getSource();
	            if (tBtn.isSelected()) {
	            	valitut[4] = true;
	            } else valitut[4] = false;
			}
		});
		frame.getContentPane().add(button_4);


		
		
		
		
	
		
	}
	
	/*
	 * Pelaajan vaihtometodi, vaihtaa pelaajan jonka sarakkeeseen noppien arvo tallennetaan
	 */

	public static void playerSwitch(Object[][] data) {
		int counter = 0; //tarkistetaan aina ennen pelaajan vaihtoa p��ttyyk� peli nyt
		for (int i = 0; i < 17; i++){ //lasketaan montako null-arvoa pistelistassa on viel�
			if ((data[i][1] == null) || (data[i][2] == null)){
				counter += 1;
			}
		}
		if (counter == 0){
			JOptionPane.showMessageDialog(frame,
			    	"Peli on ohi.",
			    	"Ohi on.",
			    	JOptionPane.PLAIN_MESSAGE);
		}
		if (player == 1) {
			player = 2;
		} else {
			player = 1;
		}
		
		
	}
}



	
class ImagePanel extends JComponent{
	private Image image;
    public ImagePanel(Image image) {
        this.image = image;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, this);
    }

//*********************
//* TALLENNUS JA LATAUS
//*********************

/**
 * @param p1points Pelaajan pisteet arraylistana
 * @param p2points -||-
 * @throws IOException
 * @author J
 * Tallentaa pelaajien pistelistat eri tekstitiedostoihin muodossa *,*,*,*,...
 */
public void saveScores(Object[][] data) throws IOException{
	ArrayList<Integer> p1points = new ArrayList<Integer>(); //siirret��n pisteet k�sittely� varten matriisista listoihin
	ArrayList<Integer> p2points = new ArrayList<Integer>();
	for (int i = 0; i < 15; i++){
		p1points.add((Integer) data[i][1]);
		p2points.add((Integer) data[i][2]);
	}
	
	String p1sheet = "src/sheet1.txt"; //osoitetaan tallennusolio kohti oikeaa tiedostoa, tallennetaan src-kansioon txt-muodossa
	String p2sheet = "src/sheet2.txt";
	
	Save manager1 = new Save(p1sheet); //molempia pelaajia edustaa oma tallennusolio
	Save manager2 = new Save(p2sheet);
	
	manager1.writeToFile(p1points); //kutsutaan tallennusmetodia molemmille pelaajille
	manager2.writeToFile(p2points);
}


/**
 * @param data 3*15 matriisi joka sis�lt�� tulokset sarakkeissa j�rjestyksess� mjono, p1-piste, p2-piste
 * @throws FileNotFoundException 
 */
/**
 * @param data Matriisi pelaajien pisteist�. 3*15, jossa ensimm�inen sarake kertoo pisteen tyypin, toinen ja kolmas ovat pelaajien pisteet
 * @throws FileNotFoundException
 */
public void loadScores(Object[][] data) throws FileNotFoundException{
	ArrayList<Integer> p1points = new ArrayList<Integer>();
	ArrayList<Integer> p2points = new ArrayList<Integer>();
	String p1sheet = "src/sheet1.txt";
	String p2sheet = "src/sheet2.txt";
	Save manager1 = new Save(p1sheet);
	Save manager2 = new Save(p2sheet);
	p1points = manager1.readFromFile(p1sheet);
	p2points = manager2.readFromFile(p2sheet);
	for (int i = 0; i < 15; i++){
		data[i][1] = p1points.get(i);
		data[i][2] = p2points.get(i);
		}
	}
}